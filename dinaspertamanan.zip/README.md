# dinaspertamanan
Tracking Pasukan Kuning dan Sopir Truck Sampah
